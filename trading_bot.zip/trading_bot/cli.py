
import argparse
import os

from bot.client import BinanceFuturesClient
from bot.validators import validate_order
from bot.logging_config import setup_logging

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--side", required=True)
    parser.add_argument("--order_type", required=True)
    parser.add_argument("--quantity", type=float, required=True)
    parser.add_argument("--price", type=float)

    args = parser.parse_args()

    setup_logging()
    validate_order(args)

    client = BinanceFuturesClient(
        os.getenv("BINANCE_API_KEY"),
        os.getenv("BINANCE_API_SECRET")
    )

    params = {
        "symbol": args.symbol.upper(),
        "side": args.side.upper(),
        "type": args.order_type.upper(),
        "quantity": args.quantity
    }

    if args.order_type.upper() == "LIMIT":
        params["price"] = args.price
        params["timeInForce"] = "GTC"

    print("Order Summary:", params)

    response = client.place_order(**params)

    print("\nOrder Response")
    print("Order ID:", response.get("orderId"))
    print("Status:", response.get("status"))
    print("Executed Qty:", response.get("executedQty"))
    print("Avg Price:", response.get("avgPrice"))
    print("Order placed successfully!")

if __name__ == "__main__":
    main()
