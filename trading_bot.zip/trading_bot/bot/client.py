
import logging
from binance.client import Client
from binance.exceptions import BinanceAPIException

class BinanceFuturesClient:
    def __init__(self, api_key, api_secret):
        self.client = Client(api_key, api_secret)
        self.client.FUTURES_URL = "https://testnet.binancefuture.com/fapi"

    def place_order(self, **params):
        logging.info("Order Request: %s", params)
        try:
            response = self.client.futures_create_order(**params)
            logging.info("Order Response: %s", response)
            return response
        except BinanceAPIException as e:
            logging.error("Binance API Error: %s", e)
            raise
        except Exception as e:
            logging.exception("Unexpected Error")
            raise
