
# Binance Futures Testnet Trading Bot

## Setup
pip install -r requirements.txt

Export credentials:
export BINANCE_API_KEY=<key>
export BINANCE_API_SECRET=<secret>

## Run Examples

Market Order:
python cli.py --symbol BTCUSDT --side BUY --order_type MARKET --quantity 0.001

Limit Order:
python cli.py --symbol BTCUSDT --side SELL --order_type LIMIT --quantity 0.001 --price 100000

## Assumptions
- Binance Futures Testnet account is configured.
- API credentials are valid.
